package com.Noboghat.mahi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MahiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MahiApplication.class, args);
	}

}
